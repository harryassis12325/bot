import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import ParseMode
from aiogram.utils import executor
import json
import os

from utils.admin import exibir_precos_admin, atualizar_preco
from utils.pagamento import processar_pagamento_pix
from utils.precos import obter_preco_normal_por_bin, obter_preco_promocional_por_bin

API_TOKEN = '7621055206:AAFR5zOnevfzpb1-QaP3go7oRTKs0sxwaOs'
ADMIN_ID = 2134095059  # ID do administrador

# Configura o bot e o dispatcher
logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Comando /start
@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    user_id = message.from_user.id
    # Salva o usuário no banco de dados ou exibe mensagem de boas-vindas
    await message.answer("Bem-vindo ao Bot de Compras! Selecione uma das opções abaixo.")
    await mostrar_menu(message)

# Comando para mostrar o menu
async def mostrar_menu(message: types.Message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("Compra CC", "Compra CC Promocional")
    await message.answer("Escolha uma opção:", reply_markup=markup)

# Comando para mostrar preços de cartões
@dp.message_handler(commands=['precos'])
async def precos(message: types.Message):
    await exibir_precos_admin(message)

# Comando para atualizar preços (somente admin)
@dp.message_handler(commands=['atualizar_preco'])
async def atualizar_precos(message: types.Message):
    partes = message.text.split()
    if len(partes) != 4:
        await message.answer("Uso correto: /atualizar_preco <tipo> <bin> <novo_valor>")
        return
    tipo, bin_cartao, novo_valor = partes[1], partes[2], float(partes[3])
    await atualizar_preco(message, tipo, bin_cartao, novo_valor)

# Comando para processar pagamento Pix
@dp.message_handler(commands=['pix'])
async def pix(message: types.Message):
    partes = message.text.split()
    if len(partes) != 2:
        await message.answer("Uso correto: /pix <valor>")
        return
    valor = float(partes[1])
    await processar_pagamento_pix(message, valor)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)

