import json
from aiogram import types

# Função para exibir os preços dos cartões no painel
async def exibir_precos_admin(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("Você não tem permissão para acessar essa funcionalidade.")
        return

    try:
        with open('config.json', 'r') as f:
            data = json.load(f)
        precos_normal = data.get("precos", {}).get("normal", {})
        precos_promocional = data.get("precos", {}).get("promocional", {})

        precos_texto = "📊 **Preços Atuais dos Cartões (por BIN):**\n\n"
        if precos_normal:
            precos_texto += "**Cartões Normais:**\n"
            for bin_cartao, valor in precos_normal.items():
                precos_texto += f"BIN {bin_cartao}: R${valor:.2f}\n"

        if precos_promocional:
            precos_texto += "\n**Cartões Promocionais:**\n"
            for bin_cartao, valor in precos_promocional.items():
                precos_texto += f"BIN {bin_cartao}: R${valor:.2f}\n"

        await message.answer(precos_texto)
    except FileNotFoundError:
        await message.answer("Erro ao acessar os dados. Tente novamente mais tarde.")

# Função para atualizar os preços
async def atualizar_preco(message: types.Message, tipo: str, bin_cartao: str, novo_valor: float):
    if message.from_user.id != ADMIN_ID:
        await message.answer("Você não tem permissão para acessar essa funcionalidade.")
        return

    try:
        with open('config.json', 'r') as f:
            data = json.load(f)

        if tipo == "normal":
            data["precos"]["normal"][bin_cartao] = novo_valor
        elif tipo == "promocional":
            data["precos"]["promocional"][bin_cartao] = novo_valor
        else:
            await message.answer("Tipo inválido. Use 'normal' ou 'promocional'.")
            return

        with open('config.json', 'w') as f:
            json.dump(data, f)

        await message.answer(f"✅ O preço do cartão {bin_cartao} foi atualizado para R${novo_valor:.2f}.")
    except FileNotFoundError:
        await message.answer("Erro ao atualizar os dados. Tente novamente mais tarde.")
