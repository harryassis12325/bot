import requests
from aiogram import types

# Função para processar pagamento Pix
async def processar_pagamento_pix(message: types.Message, valor: float):
    # Exemplo de integração com a API de Pix
    chave_pix = "chave_pix_do_admin"  # A chave Pix que o admin define
    nome = "Nome do Admin"
    banco = "Banco Exemplo"

    # Gerando os dados para o pagamento (um exemplo simplificado)
    pagamento = {
        "valor": valor,
        "chave_pix": chave_pix,
        "nome": nome,
        "banco": banco
    }

    # Aqui você integraria com a API do Pix ou faria a lógica necessária
    await message.answer(f"Processando pagamento de R${valor:.2f} via Pix...\n"
                         f"Nome: {nome}\nBanco: {banco}\nChave Pix: {chave_pix}")
