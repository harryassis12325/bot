import json

# Função para obter o preço de um cartão normal
def obter_preco_normal_por_bin(cartao: str):
    bin_cartao = cartao[:6]
    try:
        with open('config.json', 'r') as f:
            data = json.load(f)
        precos = data.get("precos", {}).get("normal", {})
        return precos.get(bin_cartao, None)
    except FileNotFoundError:
        return None

# Função para obter o preço de um cartão promocional
def obter_preco_promocional_por_bin(cartao: str):
    bin_cartao = cartao[:6]
    try:
        with open('config.json', 'r') as f:
            data = json.load(f)
        precos = data.get("precos", {}).get("promocional", {})
        return precos.get(bin_cartao, None)
    except FileNotFoundError:
        return None
